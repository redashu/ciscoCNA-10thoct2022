<?php

echo "Hello world";
echo phpinfo();

?>
